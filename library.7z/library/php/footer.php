<link rel="stylesheet" href="../css/footer.css">

<div class="footer">
    &copy; <?php echo date("Y"); ?> BBL, Designed by KLCT. All Rights Reserved.
</div>